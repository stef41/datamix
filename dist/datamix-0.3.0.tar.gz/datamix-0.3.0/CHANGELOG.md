# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2025-04-10

### Added
- Add dataset diversity metrics in `diversity.py`
- Add token budget calculator via `calculator.py`

## [0.2.0] - 2026-04-10

### Added
- Add automatic dataset ratio optimization
- Add streaming dataset support
- Add YAML and JSON config format for mix recipes

## [0.1.0] - 2026-04-10

### Added
- Initial release: dataset mixing and curriculum optimizer

